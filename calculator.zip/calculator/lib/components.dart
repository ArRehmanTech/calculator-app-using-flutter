import 'package:flutter/material.dart';

const Color grayColor = Colors.lightBlue;

const headingTextSytle = TextStyle(
  fontSize: 23,
  fontWeight: FontWeight.w200,
  color: Colors.white,
);
